<?php

$dbhost = "localhost";
$dbname = "db_forecastses";
$dbuser = "root";
$dbpass = "";

$koneksi = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

?>