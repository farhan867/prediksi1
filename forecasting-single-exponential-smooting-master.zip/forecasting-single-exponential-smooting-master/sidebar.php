  <div class="sidebar-container">
  	<div class="sidebar-logo">
  		Forecasting SB Group
  	</div>
  	<ul class="sidebar-navigation">
  		<li class="header">Navigasi</li>
  		<li>
  			<a href="index.php">
  				<i class="fa fa-home" aria-hidden="true"></i>Home
  			</a>
  		</li>
  		<li>
  			<a href="data.php">
  				<i class="fa fa-shopping-bag" aria-hidden="true"></i>Data Penjualan
  			</a>
  		</li>
  		<li>
  			<a href="forecast.php">
  				<i class="fa fa-database" aria-hidden="true"></i>Forecasting
  			</a>
  		</li>
  		<li class="header">Menu Lainnya</li>
        <li>
            <a href="data_admin.php">
                <i class="fa fa-users" aria-hidden="true"></i>Data Admin
            </a>
        </li>
  		<li>
  			<a href="tentang_kami.php">
  				<i class="fa fa-coffee" aria-hidden="true"></i>Tentang Kami
  			</a>
  		</li>
        <li>
            <a href="logout.php">
                <i class="fa fa-window-close" aria-hidden="true"></i>Keluar
            </a>
        </li>
  	</ul>
  </div>